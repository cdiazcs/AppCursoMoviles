package com.example.mykotcalculadorabasica

class LogicaCalculadora {

    fun calculate(a: Double, b: Double, operator: String): Double {
        return when (operator) {
            "+" -> a + b
            "-" -> a - b
            "×" -> a * b
            "÷" -> a / b
            else -> 0.0
        }
    }

}