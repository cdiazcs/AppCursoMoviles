package com.example.mykotcalculadorabasica
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



class MainActivity : AppCompatActivity() {
    private lateinit var tvDisplay: TextView
    private val engine = LogicaCalculadora()

    private var currentInput = ""
    private var firstNumber = 0.0
    private var operator = ""
    private var isNewOperation = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvDisplay = findViewById(R.id.tvDisplay)

        val btn0 = findViewById<Button>(R.id.btn0)
        val btn1 = findViewById<Button>(R.id.btn1)
        val btn2 = findViewById<Button>(R.id.btn2)
        val btn3 = findViewById<Button>(R.id.btn3)
        val btn4 = findViewById<Button>(R.id.btn4)
        val btn5 = findViewById<Button>(R.id.btn5)
        val btn6 = findViewById<Button>(R.id.btn6)
        val btn7 = findViewById<Button>(R.id.btn7)
        val btn8 = findViewById<Button>(R.id.btn8)
        val btn9 = findViewById<Button>(R.id.btn9)

        val btnDot = findViewById<Button>(R.id.btnDot)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)
        val btnEqual = findViewById<Button>(R.id.btnEqual)

        btn0.setOnClickListener { appendNumber("0") }
        btn1.setOnClickListener { appendNumber("1") }
        btn2.setOnClickListener { appendNumber("2") }
        btn3.setOnClickListener { appendNumber("3") }
        btn4.setOnClickListener { appendNumber("4") }
        btn5.setOnClickListener { appendNumber("5") }
        btn6.setOnClickListener { appendNumber("6") }
        btn7.setOnClickListener { appendNumber("7") }
        btn8.setOnClickListener { appendNumber("8") }
        btn9.setOnClickListener { appendNumber("9") }

        btnDot.setOnClickListener { appendDot() }

        btnAdd.setOnClickListener { setOperator("+") }
        btnSubtract.setOnClickListener { setOperator("-") }
        btnMultiply.setOnClickListener { setOperator("×") }
        btnDivide.setOnClickListener { setOperator("÷") }

        btnEqual.setOnClickListener { calculateResult() }
    }

    private fun appendNumber(number: String) {
        if (isNewOperation) {
            currentInput = ""
            isNewOperation = false
        }

        currentInput += number
        tvDisplay.text = currentInput
    }

    private fun appendDot() {
        if (isNewOperation) {
            currentInput = ""
            isNewOperation = false
        }

        if (!currentInput.contains(".")) {
            if (currentInput.isEmpty()) {
                currentInput = "0."
            } else {
                currentInput += "."
            }
            tvDisplay.text = currentInput
        }
    }

    private fun setOperator(op: String) {
        if (currentInput.isNotEmpty()) {
            firstNumber = currentInput.toDouble()
            operator = op
            isNewOperation = true
        }
    }

    private fun calculateResult() {
        if (currentInput.isNotEmpty() && operator.isNotEmpty()) {
            val secondNumber = currentInput.toDouble()

            if (operator == "÷" && secondNumber == 0.0) {
                tvDisplay.text = "Error"
                currentInput = ""
                operator = ""
                return
            }

            val result = engine.calculate(firstNumber, secondNumber, operator)

            currentInput = if (result % 1 == 0.0) {
                result.toInt().toString()
            } else {
                result.toString()
            }

            tvDisplay.text = currentInput
            operator = ""
            isNewOperation = true
        }
    }
}